"use strict";
var home_component_1 = require('./home.component');
var user_component_1 = require('./user/user.component');
var APP_ROUTES = [
    { path: 'user/:id', component: user_component_1.UserComponent },
    //{ path: 'user/:id', component: UserComponent, children: USER_ROUTES},
    { path: '', component: home_component_1.HomeComponent },
    { path: '**', redirectTo: '/user/1' }
];
//export const routing = RouterModule.forRoot(APP_ROUTES); 
//# sourceMappingURL=app.routing.js.map