"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
//import {Response} from '@angular/http'
var basic_service_1 = require('./basic.service');
var BasicServiceComponent = (function () {
    function BasicServiceComponent(basicService) {
        this.basicService = basicService;
        this.asyncString = this.basicService.getData();
    }
    BasicServiceComponent.prototype.ngOnInit = function () {
        this.basicService.getData()
            .subscribe(function (data) { return console.log(data); });
    };
    BasicServiceComponent.prototype.onSubmit = function (username, email) {
        this.basicService.sendData({ username: username, email: email })
            .subscribe(function (data) { return console.log(data); }, function (error) { return console.log(error); });
    };
    BasicServiceComponent.prototype.onGetData = function () {
        var _this = this;
        this.basicService.getOwnData()
            .subscribe(function (data) {
            var myArray = [];
            for (var key in data) {
                myArray.push(data[key]);
            }
            _this.items = myArray;
        });
    };
    BasicServiceComponent = __decorate([
        core_1.Component({
            moduleId: module.id,
            selector: 'basic-http',
            templateUrl: './basic.service.html',
            providers: [basic_service_1.BasicService]
        }), 
        __metadata('design:paramtypes', [basic_service_1.BasicService])
    ], BasicServiceComponent);
    return BasicServiceComponent;
}());
exports.BasicServiceComponent = BasicServiceComponent;
//# sourceMappingURL=basic.service.component.js.map