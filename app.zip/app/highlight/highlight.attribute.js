"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
//import {Directive, ElementRef, Renderer} from '@angular/core'
var core_1 = require('@angular/core');
var HighlightAttribute = (function () {
    //constructor(private elementRef: ElementRef, private renderer: Renderer){
    //this.elementRef.nativeElement.style.backgroundColor="green";
    //this.renderer.setElementStyle(this.elementRef.nativeElement, 'background-color', 'green');
    //}
    function HighlightAttribute() {
        this.highlightColor = 'green';
        this.backgroundColor = this.defaultColor;
    }
    HighlightAttribute.prototype.mouseenter = function () {
        this.backgroundColor = this.highlightColor;
    };
    ;
    HighlightAttribute.prototype.mouseleave = function () {
        this.backgroundColor = this.defaultColor;
    };
    Object.defineProperty(HighlightAttribute.prototype, "setBackgroundColor", {
        get: function () {
            return this.backgroundColor;
        },
        enumerable: true,
        configurable: true
    });
    HighlightAttribute.prototype.ngOnInit = function () {
        this.backgroundColor = this.defaultColor;
    };
    __decorate([
        core_1.Input(), 
        __metadata('design:type', String)
    ], HighlightAttribute.prototype, "defaultColor", void 0);
    __decorate([
        core_1.Input('highlight'), 
        __metadata('design:type', Object)
    ], HighlightAttribute.prototype, "highlightColor", void 0);
    __decorate([
        core_1.HostListener('mouseenter'), 
        __metadata('design:type', Function), 
        __metadata('design:paramtypes', []), 
        __metadata('design:returntype', void 0)
    ], HighlightAttribute.prototype, "mouseenter", null);
    __decorate([
        core_1.HostListener('mouseleave'), 
        __metadata('design:type', Function), 
        __metadata('design:paramtypes', []), 
        __metadata('design:returntype', void 0)
    ], HighlightAttribute.prototype, "mouseleave", null);
    __decorate([
        core_1.HostBinding('style.backgroundColor'), 
        __metadata('design:type', Object)
    ], HighlightAttribute.prototype, "setBackgroundColor", null);
    HighlightAttribute = __decorate([
        core_1.Directive({
            selector: '[highlight]'
        }), 
        __metadata('design:paramtypes', [])
    ], HighlightAttribute);
    return HighlightAttribute;
}());
exports.HighlightAttribute = HighlightAttribute;
//# sourceMappingURL=highlight.attribute.js.map