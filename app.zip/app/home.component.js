"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var router_1 = require('@angular/router');
var HomeComponent = (function () {
    function HomeComponent(route) {
        var _this = this;
        this.route = route;
        this.subscription = route.queryParams.subscribe(function (qParam) { return _this.param = qParam['analytics']; });
    }
    HomeComponent.prototype.ngOnDestroy = function () {
        this.subscription.unsubscribe();
    };
    HomeComponent = __decorate([
        core_1.Component({
            moduleId: module.id,
            selector: 'home-component',
            template: "\n        <h1>Home Component!</h1>\n        Param: {{param}}\n        <hr>\n        <h1>Lorem Ipsum</h1>\n        <div>Lorem Ipsum es simplemente el texto<br> de relleno de las imprentas y archivos de texto. Lorem Ipsum ha sido el texto de relleno est\u00E1ndar de las industrias desde el a\u00F1o 1500, cuando un impresor (N. del T. persona que se dedica a la imprenta) desconocido us\u00F3 una galer\u00EDa de textos y los mezcl\u00F3 de tal manera que logr\u00F3 hacer un <br>libro de textos especimen. No s\u00F3lo sobrevivi\u00F3 500 a\u00F1os, sino que tambien ingres\u00F3 como texto de relleno en documentos electr\u00F3nicos, quedando esencialmente igual al original. Fue popularizado en los 60s con la creaci\u00F3n de las hojas \"Letraset\", las cuales contenian pasajes de Lorem Ipsum,<br> y m\u00E1s recientemente con software de autoedici\u00F3n, como por ejemplo Aldus PageMaker, el cual incluye versiones de Lorem Ipsum.\n        </div>\n<br>\n\n<a name=\"section1\" id=\"section1\">Section 1</a>\n    "
        }), 
        __metadata('design:paramtypes', [router_1.ActivatedRoute])
    ], HomeComponent);
    return HomeComponent;
}());
exports.HomeComponent = HomeComponent;
//# sourceMappingURL=home.component.js.map