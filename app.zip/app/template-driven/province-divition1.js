"use strict";
var ProvinceDivition1 = (function () {
    function ProvinceDivition1(id, name) {
        this.id = id;
        this.name = name;
    }
    return ProvinceDivition1;
}());
exports.ProvinceDivition1 = ProvinceDivition1;
//# sourceMappingURL=province-divition1.js.map