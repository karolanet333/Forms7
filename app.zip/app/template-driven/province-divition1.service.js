"use strict";
var province_divition1_1 = require('./province-divition1');
var ProvinceDivition1Service = (function () {
    function ProvinceDivition1Service() {
    }
    ProvinceDivition1Service.prototype.getProvinceDivitions1 = function () {
        var p = [
            new province_divition1_1.ProvinceDivition1(1, "Lanus"),
            new province_divition1_1.ProvinceDivition1(2, "Avellaneda"),
            new province_divition1_1.ProvinceDivition1(3, "Lomas de Zamora"),
            new province_divition1_1.ProvinceDivition1(4, "Otras")
        ];
        return p;
    };
    return ProvinceDivition1Service;
}());
exports.ProvinceDivition1Service = ProvinceDivition1Service;
//# sourceMappingURL=province-divition1.service.js.map