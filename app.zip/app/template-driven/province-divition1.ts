export class ProvinceDivition1{
    constructor(public id: number, public name:string){}
}