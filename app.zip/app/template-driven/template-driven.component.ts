import {Component} from '@angular/core';
import {NgForm} from '@angular/forms';
import {ProvinceDivition1} from './province-divition1'
import {ProvinceDivition1Service} from './province-divition1.service'

@Component({
    moduleId: module.id,
    selector: 'template-driven',
    templateUrl: './template-driven.component.html',
    providers: [ProvinceDivition1Service]
})
export class TemplateDrivenComponent{

    provinceDivitions1: [ProvinceDivition1]

    constructor(private provinceDivition1Service: ProvinceDivition1Service){
        this.provinceDivitions1 = provinceDivition1Service.getProvinceDivitions1();
    }

    user = {
        username: 'pepe',
        email: 'pepe@argento.com',
        password: 'qqq',
        gender: 'male',
        country: 'Brasil',
        province: 4,
        provinceDivition1: 3,
        sports: [1, 3]
    };

    genders = [
        'male',
        'female'
    ];

    countries = [
        'Argentina',
        'EEUU',
        'España',
        'Brasil'
    ];

    provinces = [
        {id:1, name:'Buenos Aires'},
        {id:2, name:'Cordoba'},
        {id:3, name:'Santa Fe'},
        {id:4, name:'Otra'}
    ];

    sports = [
        {id:0, name: 'Gym', checked: false},
        {id:1, name: 'Basket', checked: true},
        {id:2, name: 'Yoga', checked: false},
        {id:3, name: 'Boley', checked: false}
    ];

    /*provinceDivitions1 = [
        {id:1, name:'Lanus'},
        {id:2, name:'Avellaneda'},
        {id:3, name:'Lomas de Zamora'},
        {id:4, name:'Otra'}
    ];*/

    onSubmit(form: NgForm){
        console.log(form.value);

        let selectedSports = this.getSelectedSports();

        console.log(selectedSports);
    }

    getSelectedSports(): number[] { // right now: ['1','3']
        return this.sports
                .filter(opt => opt.checked)
                .map(opt => opt.id)
   }

   changeSport(index: number, event: any){
       this.sports[index].checked = event.currentTarget.checked;
   }
}