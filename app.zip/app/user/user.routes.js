"use strict";
var user_detail_1 = require("./user.detail");
var user_edit_1 = require("./user.edit");
var user_detail_guard_1 = require("./user-detail.guard");
var user_edit_guard_1 = require("./user-edit.guard");
exports.USER_ROUTES = [
    { path: 'detail', component: user_detail_1.UserDetailComponent, canActivate: [user_detail_guard_1.UserDetailGuard] },
    { path: 'edit', component: user_edit_1.UserEditComponent, canDeactivate: [user_edit_guard_1.UserEditGuard] }
];
//# sourceMappingURL=user.routes.js.map